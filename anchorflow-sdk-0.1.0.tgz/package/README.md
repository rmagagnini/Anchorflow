# AnchorFlow SDK

> TypeScript SDK for Stellar anchor integration — SEP-1, SEP-6, SEP-10, SEP-12, SEP-24, SEP-31, SEP-38

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.6-blue.svg)](https://www.typescriptlang.org/)
[![Tests](https://img.shields.io/badge/tests-159%20passing-brightgreen.svg)]()

AnchorFlow SDK abstracts the complexity of Stellar's SEP protocols into a clean, typed TypeScript API. Your application never needs to know which SEP version an anchor uses — the SDK handles discovery, authentication, KYC, protocol routing, and transaction monitoring automatically.

---

## Architecture

---

## Installation

```bash
npm install anchorflow-sdk
```

---

## Quick Start

```typescript
import { AnchorFlow } from 'anchorflow-sdk';

const sdk = new AnchorFlow({ network: 'testnet' });

// 1. Discover anchor capabilities (SEP-1)
const anchor = await sdk.getAnchorInfo('testanchor.stellar.org');
console.log(anchor.capabilities);
// { sep6: true, sep10: true, sep24: true, sep38: true, ... }

// 2. Authenticate (SEP-10)
const auth = await sdk.authenticate('testanchor.stellar.org', {
  account: 'G...your_public_key',
  signTransaction: async (xdr, networkPassphrase) => {
    // sign with your keypair and return signed XDR
    return signedXdr;
  },
});

// 3. Smart deposit — SDK picks SEP-24 or SEP-6 automatically
const deposit = await sdk.smartDeposit(
  'testanchor.stellar.org',
  { assetCode: 'USDC', account: 'G...your_public_key' },
  auth.token
);

// SEP-24: deposit.url  → open in iframe/webview
// SEP-6:  deposit.how  → payment instructions

// 4. Poll until complete
const result = await sdk.pollTransaction(
  'testanchor.stellar.org',
  deposit.id,
  auth.token,
  {
    onStatusChange: (tx) => console.log('Status:', tx.status),
  }
);

console.log(result.status); // 'completed' | 'error' | 'refunded'
```

---

## SEP Protocol Reference

| Protocol | Purpose | Main Methods |
|---|---|---|
| SEP-1 | Anchor discovery via `stellar.toml` | `getAnchorInfo()` |
| SEP-10 | JWT Web Authentication | `authenticate()` |
| SEP-12 | KYC — customer identity | `getKycStatus()`, `submitKyc()`, `ensureKycComplete()` |
| SEP-6 | Programmatic deposit & withdrawal | `depositSep6()`, `withdrawSep6()` |
| SEP-24 | Interactive deposit & withdrawal | `depositSep24()`, `withdrawSep24()` |
| SEP-31 | Cross-border payments | `sendCrossBorder()` |
| SEP-38 | Quote / Exchange rates | `getIndicativePrice()`, `requestFirmQuote()` |

---

## Full Transaction Flow

```typescript
const sdk = new AnchorFlow({ network: 'mainnet' });

// Step 1: Discover
const { capabilities } = await sdk.getAnchorInfo('myanchor.com');

// Step 2: Authenticate
const auth = await sdk.authenticate('myanchor.com', {
  account: userPublicKey,
  signTransaction: walletSign,
});

// Step 3: KYC (if required)
if (capabilities.sep12) {
  await sdk.ensureKycComplete('myanchor.com', auth.token, {
    account: userPublicKey,
    first_name: 'João',
    last_name: 'Silva',
    email_address: 'joao@email.com',
  });
}

// Step 4: Get exchange rate (SEP-38)
if (capabilities.sep38) {
  const price = await sdk.getIndicativePrice('myanchor.com', {
    sellAsset: 'stellar:USDC:GBBD47...',
    buyAsset: 'iso4217:BRL',
    sellAmount: '100',
    context: 'sep6',
  }, auth.token);
  console.log(`Rate: ${price.price} BRL per USDC`);
}

// Step 5: Deposit
const deposit = await sdk.smartDeposit(
  'myanchor.com',
  { assetCode: 'USDC', account: userPublicKey },
  auth.token
);

// Step 6: Monitor
const final = await sdk.pollTransaction('myanchor.com', deposit.id, auth.token, {
  interval: 5_000,
  maxAttempts: 120,
  onStatusChange: (tx) => updateUI(tx.status),
});
```

---

## SEP-38: Quote / Exchange

```typescript
// Indicative price (non-binding)
const price = await sdk.getIndicativePrice('anchor.com', {
  sellAsset: 'stellar:USDC:GBBD47...',
  buyAsset: 'iso4217:BRL',
  sellAmount: '100',
  context: 'sep6',
}, token);

console.log(price.price);       // '5.42'
console.log(price.buy_amount);  // '542'
console.log(price.fee.total);   // '8'

// Firm quote (anchor guarantees the rate)
const quote = await sdk.requestFirmQuote('anchor.com', {
  sellAsset: 'stellar:USDC:GBBD47...',
  buyAsset: 'iso4217:BRL',
  sellAmount: '100',
  context: 'sep6',
}, token);

console.log(quote.id);          // use in deposit request
console.log(quote.expires_at);  // rate guaranteed until this time

// Use quote in deposit
await sdk.depositSep6('anchor.com', {
  assetCode: 'USDC',
  account: userAccount,
  quoteId: quote.id,
}, token);
```

---

## Observability — Event System

```typescript
const sdk = new AnchorFlow({ network: 'mainnet' });

// Listen to all lifecycle events
sdk.on('discovery:success', ({ domain, capabilities }) => {
  console.log(`Anchor ${domain} supports SEP-24: ${capabilities.sep24}`);
});

sdk.on('auth:success', ({ account, expiresAt }) => {
  console.log(`JWT valid until ${expiresAt.toISOString()}`);
});

sdk.on('poll:status_change', ({ status, transaction }) => {
  updateUI(status);
});

sdk.on('poll:completed', ({ transactionId }) => {
  console.log(`Transaction ${transactionId} completed!`);
});

// Integrate with error monitoring (e.g. Sentry)
sdk.on('error', ({ code, message, error }) => {
  Sentry.captureException(error, { extra: { code } });
});

// Unsubscribe
const unsub = sdk.on('auth:success', handler);
unsub(); // removes the listener
```

### Available Events

| Event | When it fires |
|---|---|
| `discovery:start/success/error` | Fetching stellar.toml |
| `auth:start/challenge/success/error` | SEP-10 authentication |
| `kyc:check/needs_info/submit/accepted/rejected` | KYC lifecycle |
| `sep6:deposit_start/success/error` | SEP-6 deposit |
| `sep24:deposit_start/url/error` | SEP-24 deposit |
| `sep31:send_start/success/error` | Cross-border send |
| `quote:price_check/requested/expired` | SEP-38 quotes |
| `poll:start/status_change/completed/timeout` | Transaction polling |
| `error` | Any SDK error |

---

## Error Handling

```typescript
import { isAnchorFlowError, KycError, AuthError } from 'anchorflow-sdk';

try {
  await sdk.authenticate('anchor.com', options);
} catch (error) {
  if (isAnchorFlowError(error)) {
    console.error(error.code);        // 'AUTH_CHALLENGE_FAILED'
    console.error(error.httpStatus);  // 401
    console.error(error.anchorDomain);
  }
  if (error instanceof KycError) {
    console.error('Missing fields:', error.missingFields);
  }
}
```

### Error Codes

| Code | Description |
|---|---|
| `TOML_FETCH_FAILED` | Could not reach anchor's stellar.toml |
| `AUTH_CHALLENGE_FAILED` | SEP-10 challenge request failed |
| `AUTH_SIGN_FAILED` | Transaction signing failed |
| `AUTH_SUBMIT_FAILED` | JWT submission failed |
| `KYC_MISSING_FIELDS` | Customer has unfilled required KYC fields |
| `KYC_REJECTED` | KYC was rejected by the anchor |
| `DEPOSIT_FAILED` | SEP-6 deposit request failed |
| `WITHDRAW_FAILED` | SEP-6 withdrawal request failed |
| `SEP24_INIT_FAILED` | SEP-24 interactive session failed |
| `SEP31_SEND_FAILED` | Cross-border payment failed |
| `POLLING_TIMEOUT` | Transaction did not resolve within max attempts |
| `ANCHOR_NOT_SUPPORTED` | Anchor lacks the required SEP protocol |
| `PROTOCOL_NOT_SUPPORTED` | No compatible protocol found |
| `INVALID_CONFIG` | Invalid SDK configuration |

---

## Configuration

```typescript
const sdk = new AnchorFlow({
  network: 'mainnet',            // 'mainnet' | 'testnet'
  horizonUrl: 'https://...',     // custom Horizon endpoint (optional)
  tomlCacheTtl: 300_000,         // stellar.toml cache: 5 min (default)
  sessionCacheTtl: 3_600_000,    // JWT cache: 1 hour (default)
  pollingInterval: 5_000,        // poll every 5 sec (default)
  maxPollingAttempts: 120,       // ~10 min timeout (default)
});
```

---

## Cross-Border Payments (SEP-31)

```typescript
// Register sender and receiver via KYC first
const sender = await sdk.submitKyc('anchor.com', token, senderData);
const receiver = await sdk.submitKyc('anchor.com', token, receiverData);

// Send cross-border payment
const payment = await sdk.sendCrossBorder('anchor.com', {
  amount: '1000.00',
  assetCode: 'USDC',
  assetIssuer: 'GA5ZSEJ...',
  senderId: sender.id,
  receiverId: receiver.id,
}, token);

// Send Stellar payment to:
// payment.stellar_account_id  ← destination account
// payment.stellar_memo        ← include this memo
// payment.stellar_memo_type   ← memo type
```

---

## Development

```bash
npm install          # install dependencies
npm test             # run 159 tests
npm run test:coverage # run with coverage report
npm run build        # compile TypeScript → dist/
npm run typecheck    # type-check without building
npm run lint         # ESLint
```

---

## License

MIT © AnchorFlow