# AnchorFlow SDK

> TypeScript SDK for Stellar anchor integration — SEP-1, SEP-6, SEP-10, SEP-12, SEP-24, SEP-31

[![npm version](https://badge.fury.io/js/anchorflow-sdk.svg)](https://badge.fury.io/js/anchorflow-sdk)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

AnchorFlow abstracts the complexity of Stellar's SEP protocols into a clean, typed TypeScript API. Your application never needs to know which SEP version an anchor uses — the SDK handles discovery, authentication, KYC, protocol routing, and transaction monitoring automatically.

## Architecture

```
┌─────────────────────────────────────────┐
│            Application Client            │
│  (wallet, remittance app, fintech, etc)  │
└────────────────────┬────────────────────┘
                     │ AnchorFlow public API
┌────────────────────▼────────────────────┐
│              AnchorFlow SDK              │
│                                          │
│  ┌─────────┐ ┌──────┐ ┌──────────────┐  │
│  │  SEP-1  │ │SEP-10│ │    SEP-12    │  │
│  │  TOML   │ │ JWT  │ │     KYC      │  │
│  └─────────┘ └──────┘ └──────────────┘  │
│  ┌─────────┐ ┌──────┐ ┌──────────────┐  │
│  │  SEP-6  │ │SEP-24│ │    SEP-31    │  │
│  │  API    │ │  UI  │ │ Cross-border │  │
│  └─────────┘ └──────┘ └──────────────┘  │
│  ┌──────────────────────────────────┐    │
│  │  Protocol Router + Polling Engine │   │
│  └──────────────────────────────────┘    │
└────────────────────┬────────────────────┘
                     │
┌────────────────────▼────────────────────┐
│          Stellar Network + Anchors        │
│    (liquidity, FX, local settlement)     │
└─────────────────────────────────────────┘
```

## Installation

```bash
npm install anchorflow-sdk
# or
yarn add anchorflow-sdk
```

## Quick Start

```typescript
import { AnchorFlow } from 'anchorflow-sdk';

const sdk = new AnchorFlow({ network: 'testnet' });

// 1. Discover anchor capabilities
const anchor = await sdk.getAnchorInfo('testanchor.stellar.org');
console.log(anchor.capabilities);
// { sep6: true, sep10: true, sep12: true, sep24: true, sep31: false, preferredDepositProtocol: 'SEP-24' }

// 2. Authenticate (SEP-10)
const auth = await sdk.authenticate('testanchor.stellar.org', {
  account: 'GABC...XYZ',
  signTransaction: async (xdr, networkPassphrase) => {
    // Sign with your wallet keypair
    return signedXdr;
  },
});

// 3. Smart deposit — SDK picks SEP-24 or SEP-6 automatically
const result = await sdk.smartDeposit(
  'testanchor.stellar.org',
  { assetCode: 'USDC', account: 'GABC...XYZ' },
  auth.token
);

// If SEP-24: result.url (open in iframe/webview)
// If SEP-6:  result.how (payment instructions)

// 4. Poll until complete
const pollingResult = await sdk.pollTransaction(
  'testanchor.stellar.org',
  result.id,
  auth.token,
  {
    onStatusChange: (tx) => console.log('Status:', tx.status),
  }
);

console.log(pollingResult.status); // 'completed' | 'error' | 'refunded' | 'timeout'
```

## SEP Protocol Reference

| Protocol | Purpose | Method |
|---|---|---|
| SEP-1 | Anchor discovery via `stellar.toml` | `getAnchorInfo()` |
| SEP-10 | JWT authentication (challenge-response) | `authenticate()` |
| SEP-12 | KYC — customer identity verification | `getKycStatus()`, `submitKyc()`, `ensureKycComplete()` |
| SEP-6 | Programmatic deposit & withdrawal (no UI) | `depositSep6()`, `withdrawSep6()` |
| SEP-24 | Interactive deposit & withdrawal (anchor UI) | `depositSep24()`, `withdrawSep24()` |
| SEP-31 | Cross-border payments between anchors | `sendCrossBorder()` |

## Full Transaction Flow

```typescript
const sdk = new AnchorFlow({ network: 'mainnet' });

// ── Step 1: Discover ──────────────────────────────────────────────────────
const { capabilities } = await sdk.getAnchorInfo('myanchor.com');

// ── Step 2: Authenticate ──────────────────────────────────────────────────
const auth = await sdk.authenticate('myanchor.com', {
  account: userPublicKey,
  signTransaction: walletSign,
});

// ── Step 3: KYC (if required) ─────────────────────────────────────────────
if (capabilities.sep12) {
  await sdk.ensureKycComplete('myanchor.com', auth.token, {
    account: userPublicKey,
    first_name: 'João',
    last_name: 'Silva',
    email_address: 'joao@email.com',
  });
}

// ── Step 4: Deposit ───────────────────────────────────────────────────────
const deposit = await sdk.smartDeposit(
  'myanchor.com',
  { assetCode: 'BRL', account: userPublicKey },
  auth.token
);

// ── Step 5: Monitor ───────────────────────────────────────────────────────
const final = await sdk.pollTransaction('myanchor.com', deposit.id, auth.token, {
  interval: 5_000,
  maxAttempts: 120,
  onStatusChange: (tx) => updateUI(tx.status),
});
```

## Cross-Border Payments (SEP-31)

```typescript
// Register sender and receiver via KYC first, get their IDs
const senderId = await sdk.submitKyc('sender-anchor.com', auth.token, senderData);
const receiverId = await sdk.submitKyc('sender-anchor.com', auth.token, receiverData);

const payment = await sdk.sendCrossBorder('sender-anchor.com', {
  amount: '1000.00',
  assetCode: 'USDC',
  assetIssuer: 'GA5ZSEJ...',
  senderId: senderId.id,
  receiverId: receiverId.id,
}, auth.token);

// payment.stellar_account_id — send XLM/asset here
// payment.stellar_memo       — include this memo
```

## Error Handling

```typescript
import { isAnchorFlowError, KycError, AuthError } from 'anchorflow-sdk';

try {
  await sdk.authenticate('anchor.com', options);
} catch (error) {
  if (isAnchorFlowError(error)) {
    console.error(error.code);       // e.g. 'AUTH_CHALLENGE_FAILED'
    console.error(error.httpStatus); // e.g. 401
    console.error(error.anchorDomain);
  }
  if (error instanceof KycError) {
    console.error('Missing KYC fields:', error.missingFields);
  }
}
```

### Error Codes

| Code | Description |
|---|---|
| `TOML_FETCH_FAILED` | Could not reach anchor's stellar.toml |
| `AUTH_CHALLENGE_FAILED` | SEP-10 challenge request failed |
| `AUTH_SIGN_FAILED` | Transaction signing failed |
| `KYC_MISSING_FIELDS` | Customer has unfilled required KYC fields |
| `KYC_REJECTED` | KYC was rejected by the anchor |
| `DEPOSIT_FAILED` | SEP-6 deposit request failed |
| `SEP24_INIT_FAILED` | SEP-24 interactive session could not start |
| `SEP31_SEND_FAILED` | Cross-border payment request failed |
| `POLLING_TIMEOUT` | Transaction did not resolve within max attempts |
| `PROTOCOL_NOT_SUPPORTED` | Anchor lacks the required SEP protocol |

## Configuration

```typescript
const sdk = new AnchorFlow({
  network: 'mainnet',           // or 'testnet'
  horizonUrl: 'https://...',    // custom Horizon endpoint (optional)
  tomlCacheTtl: 300_000,        // stellar.toml cache: 5 min (default)
  sessionCacheTtl: 3_600_000,   // JWT cache: 1 hour (default)
  pollingInterval: 5_000,       // poll every 5 sec (default)
  maxPollingAttempts: 120,      // ~10 min timeout (default)
});
```

## Development

```bash
npm install
npm run build       # compile TypeScript
npm test            # run tests
npm run typecheck   # type-check only
npm run lint        # ESLint
```

## License

MIT © AnchorFlow
